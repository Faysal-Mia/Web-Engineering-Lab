<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "game");
define("TITLE", "Gaming news");
define("KEYWORDS", "game, esport, offline game, online game, tournament, requirments, price, social");
?>